<template>
  <div class="text-center">
    <q-avatar class="img q-mb-md" size="x1" square>
      <img :src="`/img/i-want-to.png`"/>
    </q-avatar>
    <div class="text-h2 q-mt-lg">About</div>
  </div>
</template>

<style>
.img {
  width: 500px ;
  height: 150px ;
}
</style>