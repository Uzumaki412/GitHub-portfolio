﻿using Casestudy.DAL.DomainClasses;

namespace Casestudy.Helper
{
    public class OrderHelper
    {

        public string? Email { get; set; }
        public OrderSelectionHelper[]? Selections { get; set; } 
    }
}
