﻿namespace Casestudy.DAL.DomainClasses
{
    public class OrderSelectionHelper
    {
        public int QtyOrdered { get; set; }

        public Product? Product { get; set; }
    }
}
