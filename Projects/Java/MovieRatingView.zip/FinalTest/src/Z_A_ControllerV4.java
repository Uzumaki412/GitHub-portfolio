/**
 * Program Name: Z_A_ControllerV4.java
 * Purpose: This is a controller part of Movie Category and Rating Viewer Application
 * 					It takes 2 choices from user(category name, rating). and displays the corresponding  data
 * Author: Zaid Abu Shawarib 1196606
 * Date: Aug 20, 2025
 */

import javax.swing.*;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Z_A_ControllerV4 extends JFrame
{
	//CLASS WIDE SCOPe
	private JComboBox<String> category = new JComboBox<>();
	private JComboBox<String> rating = new JComboBox<>();
	private JButton executeBtn = new JButton("Find me some films");
	
	// standard boilerplate code often seen in JDBC apps
	Connection myConn = null;
	Statement myStmt = null;
	ResultSet myRslt = null;
	
	// PreparedStatement object and strings for connection
	PreparedStatement myPrepStmt = null;
	String URL = "jdbc:mysql://localhost:3306/sakila?useSSL=false";
	String user = "root";
	String password = "password";

	// viewer
	Z_A_ViewerV4 viewer;
	
	//CONSTRUCTOR
	public Z_A_ControllerV4() throws HeadlessException
	{
		super("Zaid_AbuShawarib's Selection App for Types and Ratings");
		
		// boilerplate
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(new GridLayout(3,1,10,10));
		this.setSize(600, 200);
		this.setLocationRelativeTo(null);
		
		// create panels and add components
		JPanel panel1 = new JPanel(new GridLayout(1,2,10,10));
		panel1.add(new JLabel("Film Type:"));
		panel1.add(category);
		JPanel panel2 = new JPanel(new GridLayout(1,2,10,10));
		panel2.add(new JLabel("Film Rating:"));
		panel2.add(rating);
		JPanel panel3 = new JPanel(new FlowLayout());
		panel3.add(executeBtn);
		
		 try {
		        ResultSet rsCategory = loadComboBox("SELECT name FROM category");
		        while (rsCategory.next()) {
		            category.addItem(rsCategory.getString("name"));
		        }
		        rsCategory.getStatement().getConnection().close(); // close the connection for the category ResultSet

		        ResultSet rsRating = loadComboBox("SELECT DISTINCT rating FROM film");
		        while (rsRating.next()) {
		            rating.addItem(rsRating.getString("rating"));
		        }
		        rsRating.getStatement().getConnection().close(); // close the connection for the rating ResultSet
		    } catch (SQLException ex) {
		        ex.getMessage();
		    }
		
	
		// REGISTER THE LISTENER
		Listener listener = new Listener();
		executeBtn.addActionListener(listener);
		
		// add panels to the JFrame
	
		this.add(panel1);
		this.add(panel2);
		this.add(panel3);
		this.pack(); 
		//last line
		this.setVisible(true);
	}
	
	// inner class ActionListener
	private class Listener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent ev)
		{
			// When "Execute Query" button is clicked
			if(ev.getActionCommand().equals("Find me some films")) 
			{
					//if we have good input, then try to make the DB connection
					try
					{
						// create a Connection object by passing in the appropriate database URL, username, and password as String arguments
						myConn = DriverManager.getConnection(URL, user, password);
						
						myPrepStmt = myConn.prepareStatement(
							    "SELECT film.title, " + 
							    "film.description " +  
							    " FROM film INNER JOIN film_category ON film.film_id = film_category.film_id " + 
							    "INNER JOIN category ON film_category.category_id = category.category_id " + 
							    "WHERE category.name = ? AND film.rating = ?"
							);
						
						// fill in the parameters from the JComboBox objects
						myPrepStmt.setString(1, category.getSelectedItem().toString());
						myPrepStmt.setString(2, rating.getSelectedItem().toString());
						
						// RUN the query and assign the returned ResultSet object to myRslt
						myRslt = myPrepStmt.executeQuery();
						
						// call the DbUtils method resultSetToTableModel() and catch the returned TableModel object
						TableModel model = DbUtils.resultSetToTableModel(myRslt);
						
						// pass the TableModel object to the JTableView 
						if(viewer == null)
							viewer = new Z_A_ViewerV4(model);
						else
							viewer.table.setModel(model);
						
						
					}
					catch(SQLException ex)
					{
						System.out.println("SQLException caught, message is: " + ex.getMessage());
						ex.printStackTrace();
					}
					catch(NumberFormatException ex)
					{
						System.out.println("Number format exception, message is " + ex.getMessage());
						ex.printStackTrace();
						JOptionPane.showMessageDialog(null, "Enter numeric values for min population");
					}
					catch(Exception ex)
					{
						System.out.println("Exception message is " + ex.getMessage());
						ex.printStackTrace();
					}
					finally
					{
						try
							{
								// closing
								if(myRslt != null)
									myRslt.close();
								if(myStmt != null)
									myStmt.close();
								if(myConn != null)
									myConn.close();
							}//end try
						catch(SQLException ex)
						{
							ex.printStackTrace();
						}
					}//end finally
				}
			
		} // end of actionPerformed
	} // end of Listener

	private ResultSet loadComboBox(String query) throws SQLException {
		myConn = DriverManager.getConnection(URL, user, password);
	    myStmt = myConn.createStatement();
	    return myStmt.executeQuery(query);
	}
	
	
	public static void main(String[] args)
	{
		new Z_A_ControllerV4();
	}

}

//end class
