/**
 * Program Name: Z_A_ViewerV4.java
 * Purpose: This is the view part of  Movie Category and Rating Viewer Application
 * Author: Zaid Abu Shawarib 1196606
 * Date: Aug 20, 2025
 */

import javax.swing.*;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.*;

public class Z_A_ViewerV4 extends JFrame
{
	public JTable table = new JTable();
	
	//constructor
	public Z_A_ViewerV4(TableModel model)
	{
		super("Zaid_AbuShawarib's Film Category and Rating Viewer");
		
		//boilerplate
		this.setLayout(new BorderLayout() );
		this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		this.setSize(500,300);
		this.setLocationRelativeTo(null);
		JPanel panel = new JPanel(new BorderLayout());
		JLabel label = new JLabel("Films meeting your criteria apper below", SwingConstants.CENTER);
		panel.add(label, BorderLayout.NORTH);
		
		//create the JTable and pass it the TableModel object that is the parameter of this method
		panel.add(table, BorderLayout.CENTER);
		table.setModel(model);
	
		//create a JScrollPane so we can see the column names on the table
		JScrollPane scrollPane = new JScrollPane(table);		
		panel.add(scrollPane, BorderLayout.CENTER);
		this.add(panel);
		//last line
		this.setVisible(true);
		
	}//end cons
}

