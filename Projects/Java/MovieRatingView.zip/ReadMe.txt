This project is a Java desktop application built with a Graphical User Interface (GUI) that connects to a database using JDBC and follows the Model-View-Controller (MVC) design pattern. The application retrieves data from a relational database and presents it in a clean, interactive interface, allowing users to view and interact with stored records.

The MVC architecture was applied to ensure a clear separation of concerns:
-Model: Handles database connectivity and queries via JDBC.
-View: Provides the user interface for displaying and interacting with data.
-Controller: Manages communication between the view and model, handling user inputs and updating the UI accordingly.

Key Highlights:
-Integrated JDBC for database connectivity and query execution.
-Implemented the MVC pattern to improve scalability and maintainability.
-Designed a GUI interface with components for displaying and updating records.
-Emphasized modular code structure and reusability.hat uses JBC and MVC 