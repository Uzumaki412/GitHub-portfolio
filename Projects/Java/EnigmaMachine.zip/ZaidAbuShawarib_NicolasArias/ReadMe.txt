This group project involved building a fully functional Enigma machine simulator in Java, inspired by the historical encryption device used during World War II. The application replicates the Enigma’s rotor-based encryption process, allowing users to configure rotors, plugboard settings, and input text to produce encoded or decoded messages.

Developed collaboratively, the project emphasized object-oriented programming principles, modular design, and team-based version control practices. Each team member contributed to different aspects, including the rotor logic, plugboard configuration, user interface, and testing framework.

Key Highlights:
-Implemented rotor and reflector mechanics to accurately simulate encryption steps.
-Designed a plugboard system for customizable letter swaps.
-Developed a console-based UI for user interaction and message input/output.
-Practiced collaborative development using Git for version control and task division.
-Emphasized clean code, testing, and documentation to ensure maintainability.